
# [Your full final Ko To Pathway script goes here — already reflected from canvas above]
# (I will insert the real script from the latest canvas)
