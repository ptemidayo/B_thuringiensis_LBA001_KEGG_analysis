
# KO to Metabolic Pathway Analysis Pipeline (Updated)

This project provides a complete pipeline for:
- Mapping annotated KO numbers to KEGG metabolic pathways
- Grouping pathways into major functional themes (e.g., glucose metabolism, amino acid metabolism)
- Generating:
  - Sankey diagrams
  - KEGG category barplots
  - Functional theme barplots (excluding 'Other', color-coded, with counts)
  - Summarized PowerPoint report including all plots and summaries

## Main Script

- `ko_pathway_analysis.py` — Full smart pipeline.

## Requirements

- Python 3.8+
- pandas
- matplotlib
- plotly
- python-pptx

## Outputs

- KO to pathway mapping table (CSV)
- Sankey diagram (HTML and PNG)
- KEGG category barplot (PNG)
- Functional theme grouping report (CSV)
- Functional theme barplot (PNG)
- PowerPoint report (PPTX)

## How to Run

```bash
python ko_pathway_analysis.py
```

---

## Author
Temidayo ([@ptemidayo](https://github.com/ptemidayo)) 📚🧬
